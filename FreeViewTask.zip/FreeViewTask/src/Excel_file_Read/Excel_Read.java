package Excel_file_Read;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class Excel_Read {
	
	public static void main(String[] args) {
		int i,j = 0;
		 Row row = null;
		try
	    {
			//giving file path to open excel
	      File fl = new File("/Users/srikanthvedala/Desktop/shruthi/Excel_data_Make_my_Trip.xls");
	      //to read excel bytes
	      FileInputStream fis= new FileInputStream(fl);
	      Workbook workbook = new HSSFWorkbook(fis);
	    
	      // to reach specific sheet
	      //Sheet sheet = workbook.getSheet("Makemytrip_TC");
	      Sheet sheet = workbook.getSheet("sheet2");
	      //System.out.println(sheet.getLastRowNum());
	        int rowCount = sheet.getLastRowNum();
	        for(i=0;i< rowCount;i++)
			{
	    	 row = sheet.getRow(i);
				for( j=0;j< row.getLastCellNum();j++)
				{
			
					System.out.print(row.getCell(j).getStringCellValue()+"|| ");
					
				}
				System.out.println(rowCount);
				
			}
	        int n;
	        if(row.getCell(j).getStringCellValue().equals("Test case")) {
	        	//go to next row
	        	
	        }
	    	   
	     
	      workbook.close();
	     
    }
    catch(IOException  e) { 
      e.printStackTrace(); 
	     
	}
	}


}
