package basepackage.Drivers;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import utility.readconfig;

public class Base {
	public static  WebDriver driver;
	//public static  Properties prop;
	 
	 
	
	public static WebDriver driver() throws IOException {
		
		/*File src= new File("/Users/srikanthvedala/eclipse-workspace/MakemyTrip_Proj/src/basepackage/Drivers/data.properties");
		FileInputStream fis= new FileInputStream(src);
		prop= new Properties();
		prop.load(fis);*/
		
		
		
	readconfig  Readconfig =new readconfig();
		String browser = readconfig.getbrowser();	
		
		
	
	System.out.println(browser);
	if(browser.equals("chrome"))
	{
		System.setProperty("webdriver.chrome.driver", Readconfig.getchromepath());
		driver=new ChromeDriver();
	}
	else if(browser.equals("Firefox"))
	{
		System.setProperty("webdriver.firefox.driver", Readconfig.getfirefoxpath());
		driver=new FirefoxDriver();
	}	
	
	
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return driver;
			
}	


	






	public void close() {
		//driver.close();
		driver.quit();
	}
	

	
}
