package freeVeiwsteps;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import basepackage.Drivers.Base;
import freeViewLaunchpageobjects.Pageobjects;
import utility.readconfig;

public class Logintestcases extends Base {

	public static void main(String args[]) throws IOException {

		driver = driver();
		readconfig Readconfig = new readconfig();
		String url = Readconfig.geturl();
		System.out.println(url);
		driver.get(url);
		Pageobjects PO = new Pageobjects(driver);
		PO.WatchTV().click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scroll(0,2000)");
		PO.Privacy_Notice().click();
		String s = driver.getCurrentUrl();
		System.out.println(s);
		String ABN = "ABN:";
		//this logic handles the extraction of the ABN from the webpage and validates. 
		List<WebElement> myList = driver
				.findElements(By.xpath("//*[@id='root']/div/main/section/div/div/div/div/p[1]"));

		if (myList.get(0).getText().contains("72 130 448 510"))
			System.out.println("ABN Validation Successful");
		else
			System.out.println("ABN Validation failure");
		//Splitting the content and concatenate string
		System.out.println(myList.get(0).getText());
		int a = (myList.get(0).getText()).indexOf("ABN:");
		int b = (myList.get(0).getText()).lastIndexOf(") and");
		String c = (myList.get(0).getText()).substring(a + 5, b);
		System.out.println(c);
		

	}
}
