package freeViewLaunchpageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Pageobjects {
	WebDriver driver;
	
	
	public Pageobjects(WebDriver driver) {
		this.driver=driver;
	}
	By Watch_TV = By.linkText("Watch TV");
	
	By Privacy_Notice = By.linkText("Privacy Notice");
	
	public WebElement WatchTV() {
		
		return driver.findElement(Watch_TV);
	}
	
		
	public WebElement Privacy_Notice () {
		return driver.findElement(Privacy_Notice );
		
	}


}
