package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;



public class readconfig {
	public static  Properties prop;
	
	public readconfig() throws IOException {
		
		
		File src= new File("/Users/srikanthvedala/eclipse-workspace/MakemyTrip_Proj/src/basepackage/Drivers/data.properties");
		FileInputStream fis= new FileInputStream(src);
		prop= new Properties();
		prop.load(fis);
		
		}
		
		

	public static String getbrowser() {
		String browser= prop.getProperty("browser");
		System.out.println(browser);
		 return browser;
	}
	public String getchromepath() {
		String chrome= prop.getProperty("chrome");
		 return chrome;
	}
	
	
	public  String getfirefoxpath() {
		String firefox= prop.getProperty("firefox");
		 return firefox;
	}
	public String geturl() {
		String url= prop.getProperty("url");
		 return url;
	}
}
	
	

	